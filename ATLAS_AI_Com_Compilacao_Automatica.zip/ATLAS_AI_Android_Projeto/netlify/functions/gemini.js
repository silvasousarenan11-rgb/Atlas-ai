exports.handler = async function (event) {
  const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Use POST." }) };
  const key = process.env.GEMINI_API_KEY;
  if (!key) return { statusCode: 500, headers, body: JSON.stringify({ error: "GEMINI_API_KEY não configurada no Netlify." }) };
  let body; try { body = JSON.parse(event.body || "{}"); } catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "Mensagem inválida." }) }; }
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message) return { statusCode: 400, headers, body: JSON.stringify({ error: "Digite uma mensagem." }) };
  if (message.length > 8000) return { statusCode: 413, headers, body: JSON.stringify({ error: "Mensagem muito longa." }) };
  try {
    const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(key);
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      systemInstruction: { parts: [{ text: "Você é ATLAS AI, um assistente prestativo. Responda em português do Brasil de forma clara, segura e útil." }] },
      contents: [{ role: "user", parts: [{ text: message }] }], generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
    }) });
    const data = await r.json();
    if (!r.ok) return { statusCode: 502, headers, body: JSON.stringify({ error: "Falha do Gemini. Confira a chave e a disponibilidade do modelo." }) };
    const reply = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("").trim();
    if (!reply) return { statusCode: 502, headers, body: JSON.stringify({ error: "Gemini não retornou texto." }) };
    return { statusCode: 200, headers, body: JSON.stringify({ reply }) };
  } catch { return { statusCode: 502, headers, body: JSON.stringify({ error: "Erro de conexão com Gemini." }) }; }
};
