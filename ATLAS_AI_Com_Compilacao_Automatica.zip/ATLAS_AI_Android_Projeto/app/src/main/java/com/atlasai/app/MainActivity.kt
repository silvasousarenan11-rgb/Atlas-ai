package com.atlasai.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    // Substitua pela URL pública da função Netlify antes de compilar.
    private val API_ENDPOINT = "https://SEU-SITE.netlify.app/.netlify/functions/gemini"
    private val bg = Color.rgb(7,20,46); private val panel = Color.rgb(16,31,64)
    private val blue = Color.rgb(78,140,255); private val white = Color.rgb(238,244,255)
    private lateinit var messages: LinearLayout; private lateinit var input: EditText
    private lateinit var scroll: ScrollView; private lateinit var status: TextView
    private lateinit var prefs: android.content.SharedPreferences; private lateinit var tts: TextToSpeech
    private var lastAnswer = ""

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        prefs=getSharedPreferences("atlas",MODE_PRIVATE); tts=TextToSpeech(this,this); buildUi()
        addMessage("Olá! Eu sou o ATLAS AI. Escreva ou fale comigo.",false); loadHistory()
    }
    private fun rounded(color:Int,radius:Int)=android.graphics.drawable.GradientDrawable().apply { setColor(color);cornerRadius=radius.toFloat();setStroke(1,Color.rgb(38,59,104)) }
    private fun button(text:String,color:Int,action:()->Unit)=Button(this).apply { this.text=text;textSize=12f;setTextColor(white);background=rounded(color,14);isAllCaps=false;setOnClickListener{action()} }
    private fun buildUi() {
        val outer=LinearLayout(this).apply { orientation=1;setPadding(18,20,18,14);setBackgroundColor(bg) }
        outer.addView(TextView(this).apply { text="✦  ATLAS AI";textSize=27f;setTextColor(white);gravity=Gravity.CENTER;setPadding(0,8,0,2);typeface=android.graphics.Typeface.DEFAULT_BOLD })
        outer.addView(TextView(this).apply { text="SEU ASSISTENTE PESSOAL";textSize=11f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,0,0,16) })
        scroll=ScrollView(this);messages=LinearLayout(this).apply { orientation=1;setPadding(12,12,12,12) };scroll.addView(messages);scroll.background=rounded(panel,20)
        outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        status=TextView(this).apply { text="Pronto para conversar";textSize=12f;setTextColor(Color.LTGRAY);setPadding(2,8,2,8) };outer.addView(status)
        input=EditText(this).apply { hint="Escreva sua mensagem...";setHintTextColor(Color.LTGRAY);setTextColor(white);textSize=16f;setSingleLine(true);imeOptions=EditorInfo.IME_ACTION_SEND;setPadding(14,8,14,8);background=rounded(Color.rgb(8,21,47),14) }
        outer.addView(input,LinearLayout.LayoutParams(-1,52))
        val row=LinearLayout(this).apply { orientation=0;gravity=Gravity.CENTER;setPadding(0,8,0,0) }
        row.addView(button("Enviar",blue){sendMessage()},LinearLayout.LayoutParams(0,48,1f))
        row.addView(button("🎙️ Falar",Color.rgb(37,58,99)){startVoice()},LinearLayout.LayoutParams(0,48,1f).apply{leftMargin=8})
        row.addView(button("🔊 Ouvir",Color.rgb(37,58,99)){speakLast()},LinearLayout.LayoutParams(0,48,1f).apply{leftMargin=8});outer.addView(row)
        val row2=LinearLayout(this).apply { orientation=0;gravity=Gravity.CENTER }
        row2.addView(button("Lembretes",Color.rgb(37,58,99)){reminders()},LinearLayout.LayoutParams(0,42,1f))
        row2.addView(button("Limpar chat",Color.rgb(37,58,99)){clearChat()},LinearLayout.LayoutParams(0,42,1f).apply{leftMargin=8})
        outer.addView(row2,LinearLayout.LayoutParams(-1,48).apply{topMargin=6})
        setContentView(outer);input.setOnEditorActionListener{_,id,_->if(id==EditorInfo.IME_ACTION_SEND){sendMessage();true}else false}
    }
    private fun addMessage(text:String,user:Boolean) {
        val b=TextView(this).apply { this.text=text;textSize=15f;setTextColor(white);setPadding(12,10,12,10);background=rounded(if(user)Color.rgb(39,85,168)else Color.rgb(26,45,84),16) }
        messages.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10;if(user)leftMargin=40 else rightMargin=30})
        scroll.post{scroll.fullScroll(View.FOCUS_DOWN)}
        val old=prefs.getString("history","")?:"";val arr=try{org.json.JSONArray(old)}catch(_:Exception){org.json.JSONArray()}
        arr.put(JSONObject().put("text",text).put("user",user));while(arr.length()>40)arr.remove(0);prefs.edit().putString("history",arr.toString()).apply()
    }
    private fun sendMessage() {
        val message=input.text.toString().trim();if(message.isEmpty())return;addMessage(message,true);input.setText("");status.text="O ATLAS está pensando..."
        if(API_ENDPOINT.contains("SEU-SITE")){addMessage("A conexão Gemini ainda precisa ser publicada e configurada. Depois disso, poderei responder com IA.",false);status.text="Configure a função Gemini.";return}
        thread { try {
            val c=(URL(API_ENDPOINT).openConnection() as HttpURLConnection).apply { requestMethod="POST";connectTimeout=20000;readTimeout=30000;doOutput=true;setRequestProperty("Content-Type","application/json; charset=utf-8") }
            c.outputStream.use{it.write(JSONObject().put("message",message).toString().toByteArray(Charsets.UTF_8))}
            val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val body=stream.bufferedReader().use{it.readText()};val obj=JSONObject(body)
            if(code !in 200..299)throw Exception("Falha Gemini")
            val reply=obj.optString("reply","Não recebi uma resposta.")
            runOnUiThread{lastAnswer=reply;addMessage(reply,false);status.text="Resposta recebida."}
        } catch(_:Exception){runOnUiThread{addMessage("Não consegui conectar. Verifique a internet e a publicação da função Gemini.",false);status.text="Falha na conexão."}} }
    }
    private fun startVoice() { try { val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");putExtra(RecognizerIntent.EXTRA_PROMPT,"Fale com o ATLAS AI")};startActivityForResult(i,21) } catch(_:Exception){Toast.makeText(this,"Voz indisponível neste aparelho.",Toast.LENGTH_LONG).show()} }
    @Deprecated("compatibilidade")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==21&&resultCode==RESULT_OK){val s=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull();if(!s.isNullOrBlank()){input.setText(s);sendMessage()}}}
    private fun speakLast(){if(lastAnswer.isBlank()){Toast.makeText(this,"Ainda não há resposta para ler.",Toast.LENGTH_SHORT).show();return};tts.language=Locale("pt","BR");tts.speak(lastAnswer,TextToSpeech.QUEUE_FLUSH,null,"atlas-answer")}
    private fun reminders(){
        val edit=EditText(this).apply{hint="Escreva um lembrete";setTextColor(white);setHintTextColor(Color.LTGRAY)}
        val saved=prefs.getString("reminders","")?:""
        android.app.AlertDialog.Builder(this).setTitle("Novo lembrete").setView(edit).setPositiveButton("Salvar"){_,_->val t=edit.text.toString().trim();if(t.isNotEmpty()){val list=(prefs.getString("reminders","")?:"").split("\n").filter{it.isNotBlank()}.toMutableList();list.add(t);prefs.edit().putString("reminders",list.joinToString("\n")).apply();Toast.makeText(this,"Lembrete salvo.",Toast.LENGTH_SHORT).show()}}
        .setNeutralButton("Ver salvos"){_,_->val items=saved.split("\n").filter{it.isNotBlank()};android.app.AlertDialog.Builder(this).setTitle("Lembretes salvos").setItems(items.toTypedArray(),null).setPositiveButton("Fechar",null).show()}.setNegativeButton("Cancelar",null).show()
    }
    private fun clearChat(){messages.removeAllViews();prefs.edit().remove("history").apply();addMessage("Conversa limpa. Como posso ajudar?",false)}
    private fun loadHistory(){val history=prefs.getString("history","")?:return;try{val a=org.json.JSONArray(history);for(i in 0 until a.length()){val o=a.getJSONObject(i);val t=o.optString("text");val b=TextView(this).apply{text=t;textSize=15f;setTextColor(white);setPadding(12,10,12,10);background=rounded(if(o.optBoolean("user"))Color.rgb(39,85,168)else Color.rgb(26,45,84),16)};messages.addView(b,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10})}}catch(_:Exception){}}
    override fun onInit(code:Int){if(code==TextToSpeech.SUCCESS)tts.language=Locale("pt","BR")}
    override fun onDestroy(){if(::tts.isInitialized){tts.stop();tts.shutdown()};super.onDestroy()}
}
